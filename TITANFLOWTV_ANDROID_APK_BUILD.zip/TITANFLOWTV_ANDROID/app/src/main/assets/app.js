const $ = (id) => document.getElementById(id);
let items = [];

function parseM3U(text) {
  const lines = text.split(/\r?\n/);
  const result = [];
  let pending = "Canal";
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const comma = line.lastIndexOf(",");
      pending = comma >= 0 ? line.slice(comma + 1).trim() : "Canal";
    } else if (!line.startsWith("#")) {
      result.push({name: pending || "Canal", url: line});
      pending = "Canal";
    }
  }
  return result;
}

$("load").addEventListener("click", async () => {
  const url = $("playlist").value.trim();
  if (!url) { alert("Ingresá la dirección de una lista M3U."); return; }
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("No se pudo descargar la lista.");
    const text = await response.text();
    items = parseM3U(text);
    if (!items.length) throw new Error("No se encontraron canales en formato M3U.");
    $("setup").classList.add("hidden");
    $("channels-panel").classList.remove("hidden");
    render(items);
  } catch (err) {
    alert("No se pudo cargar la lista. Puede que el servidor no permita conexiones desde esta app (CORS) o que la dirección no sea válida. " + err.message);
  }
});

function render(list) {
  $("channels").replaceChildren();
  for (const item of list) {
    const el = document.createElement("div");
    el.className = "channel";
    el.textContent = item.name;
    $("channels").appendChild(el);
  }
  $("count").textContent = `${list.length} elementos encontrados. Esta versión muestra nombres; la reproducción se agregará en una etapa posterior.`;
}
$("filter").addEventListener("input", () => {
  const q = $("filter").value.toLowerCase();
  render(items.filter(x => x.name.toLowerCase().includes(q)));
});
$("clear").addEventListener("click", () => {
  items = [];
  $("channels-panel").classList.add("hidden");
  $("setup").classList.remove("hidden");
  $("playlist").value = "";
  $("filter").value = "";
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}