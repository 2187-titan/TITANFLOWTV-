plugins {
    id("com.android.application")
}

android {
    namespace = "com.titanflowtv.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.titanflowtv.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
